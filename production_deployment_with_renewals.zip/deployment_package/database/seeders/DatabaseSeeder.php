<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create default admin user if not exists
        User::firstOrCreate(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Admin User',
                'password' => bcrypt('password'),
                'email_verified_at' => now(),
            ]
        );

        // Seed agents first
        $this->call(AgentSeeder::class);
        
        // Seed policies (depends on agents)
        $this->call(PolicySeeder::class);
        
        // Seed renewals (depends on policies)
        $this->call(RenewalSeeder::class);
        
        // Seed followups (depends on policies and agents)
        $this->call(FollowupSeeder::class);
    }
}
